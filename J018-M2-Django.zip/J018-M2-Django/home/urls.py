from django.urls import path
from . import views
 
urlpatterns = [
    path('', views.home, name="home"),

    #Project URLs
    path('projects/', views.projects, name="projects"),
    path("projectDetails/<str:hm>/", views.projectDetails, name ="projectDetails"),
    path("projectAdd/", views.projectAdd, name="projectAdd"),
    path("projectDelete/<str:id>/",views.projectDelete, name="projectDelete"),
    path("projectUpdate/<str:id>/", views.projectUpdate, name="projectUpdate"),

    path('contacts/', views.contacts, name="contacts"),
    path('pricing/', views.pricing, name="pricing"),
    path('skills/', views.skills, name="skills"),
] 
