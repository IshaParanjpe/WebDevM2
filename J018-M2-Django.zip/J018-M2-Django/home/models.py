from django.db import models
import email

# Create your models here.
class SpecialSkills(models.Model):
    name = models.CharField(max_length=100,null=True, blank=True)
    description = models.CharField(max_length=100,null=True,blank=True)
    link = models.CharField(max_length=100,null=True,blank=True)

    def __str__(self):
        return self.name + ' ' + self.description

    class Meta:
        verbose_name_plural = "Special Skills"


class Projects(models.Model):
    name = models.CharField(max_length=100)
    description = models.CharField(max_length=100)
    task1 = models.CharField(max_length=100)
    task2 = models.CharField(max_length=100)
    task3 = models.CharField(max_length=100)
    task4 = models.CharField(max_length=100)
    task5 = models.CharField(max_length=100)
    task6 = models.CharField(max_length=100)
    task7 = models.CharField(max_length=100)
    task8 = models.CharField(max_length=100)
    link = models.CharField(max_length=100)
    updatedat = models.DateTimeField(auto_now=True)
    createdat = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
         return self.name + ' ' + self.description
    
    class Meta:
         verbose_name_plural = "Projects"

class Pricing(models.Model):
    name = models.CharField(max_length=100)
    description = models.CharField(max_length=100)

    
    def __str__(self):
         return self.name + ' ' + self.description

    
    class Meta:
         verbose_name_plural = "Pricing"


class Profile(models.Model):
    username = models.CharField(max_length=100)
    password = models.CharField(max_length=20)

    def __str__(self):
        return self.name

    
    class Meta:
        verbose_name_plural = "Login"


class Contacts(models.Model):
    name = models.CharField(max_length=100,null=True, blank=True)
    number = models.CharField(max_length=100,null=True, blank=True)
    shortdescription = models.CharField(max_length=100,null=True, blank=True)
    updatedat = models.DateTimeField(auto_now=True)
    createdat = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name + ' ' + self.number
    
    class Meta:
        verbose_name_plural = "Contacts"