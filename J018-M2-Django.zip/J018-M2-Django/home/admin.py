from django.contrib import admin
from . import models

# Register your models here.

admin.site.register(models.Projects)
admin.site.register(models.SpecialSkills)
admin.site.register(models.Pricing)
admin.site.register(models.Profile)
admin.site.register(models.Contacts)

