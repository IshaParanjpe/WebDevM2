from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.contrib import messages
from .models import Profile, Projects, Pricing, SpecialSkills
from .forms import ProjectForms
from django.contrib.auth.decorators import login_required, permission_required

# Create your views here.
def home(request):
    return render(request, 'index.html')

def contacts(request):
    return render(request, 'contacts.html')

def pricing(request):
    try:
        data = Pricing.objects.all()
        context = {"price" : data}
    except Exception as e:
        context = {"price": "data not found"}
    return render(request, 'pricing.html', context)

def projects(request):
    try:
        data = Projects.objects.all()
        context = {"proj" : data}
    except Exception as e:
        context = {"proj": "data not found"}
    return render(request, 'projects.html', context)

@login_required(login_url='loginPage')
def projectDetails(request, hm):
    fetch_data = Projects.objects.get(name=hm)
    context = {"fetch_data":fetch_data}
    return render(request, 'projectDetails.html', context)

@login_required(login_url='loginPage')
def projectAdd(request):
    form = ProjectForms()
    if request.method == 'POST':
        myData = ProjectForms(request.POST)
        if myData.is_valid():
            myData.save()
            messages.success(request, 'Project Added Successfully')
            return redirect('projects')
    context = {"form":form}
    return render(request, 'projectAdd.html', context)

@login_required(login_url='loginPage')
def projectDelete(request, id):
    data = Projects.objects.get(id=id)
    data.delete()
    messages.warning(request, 'Project Deleted Successfully')
    return redirect('projects')

@login_required(login_url='loginPage')
def projectUpdate(request,id):
    myData = Projects.objects.get(id=id)
    updateForm = ProjectForms(request.POST or None, instance=myData)
    if updateForm.is_valid():
        updateForm.save()
        messages.success(request, 'Project Updated Successfully')
        return redirect("projects")
    context = {"form":updateForm} 
    return render(request, 'projectUpdate.html',context)


def skills(request):
    try:
        data = SpecialSkills.objects.all()
        context = {"serv" : data}
    except Exception as e:
        context = {"serv": "data not found"}
    return render(request, 'skills.html', context)




