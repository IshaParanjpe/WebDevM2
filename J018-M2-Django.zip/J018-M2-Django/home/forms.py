from pyexpat import model
from django import forms
from .models import Projects


class ProjectForms(forms.ModelForm):
    class Meta:
        model=Projects
        fields= '__all__'