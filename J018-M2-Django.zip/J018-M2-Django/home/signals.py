from django.db.models.signals import post_save, post_delete
from .models import SpecialSkills, Projects
from django.dispatch import receiver
 
@receiver(post_save,sender=Projects)
def autogenerateproject(sender,instance,created,**kwargs):
    print("signal fire automatic")
    if created:
        projectdata = instance
        # print(projectdata.name)
        # print(projectdata.techstack)
        # print(projectdata.description)
        # print(projectdata.link)
        SpecialSkills.objects.create(
            name = projectdata.name,
            description = projectdata.description,
            link= projectdata.link,
        )
 
        print("special skills created")
 
@receiver(post_delete,sender=Projects)
def autospecialskillsgone(sender,instance,**kwargs):
        projectdata = instance
        print(projectdata.name)
        print(projectdata.description)
        print(projectdata.link)
        fdata = SpecialSkills.objects.get(name=projectdata.name)
        fdata.delete()
